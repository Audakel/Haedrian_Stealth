package com.lenddo.data.models;

/**
 * Created by joseph on 6/3/14.
 */
public class CalendarDetails {
    private long id;
    private String name;

    public void setId(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
