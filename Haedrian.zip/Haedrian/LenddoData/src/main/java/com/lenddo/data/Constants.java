package com.lenddo.data;


public class Constants {
    public static final String USER_PREFERENCES = "user_preferences";
    public static final String USER_ID = "user_id";
    public static final String SMS_SENT = "sms_sent";
    public static final String PHONE_MODEL_SENT = "phone_model_sent";
}
