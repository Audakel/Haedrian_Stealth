package com.lenddo.data.listeners;

import android.location.Location;

/**
 * Created by joseph on 9/15/14.
 */
public interface OnLocationFoundListener {
    void onLocationFound(Location location);
}
