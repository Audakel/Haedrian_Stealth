package com.lenddo.widget.address;

import com.lenddo.widget.address.models.Address;

/**
 * Created by joseph on 12/4/14.
 */
public interface OnPrefillListener {
    Address getAddress();
}
