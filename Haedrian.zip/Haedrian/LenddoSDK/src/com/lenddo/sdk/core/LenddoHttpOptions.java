package com.lenddo.sdk.core;

/**
 * Created by joseph on 8/8/14.
 */
public class LenddoHttpOptions {
    public boolean usePostData;
    public boolean followRedirects;
}
