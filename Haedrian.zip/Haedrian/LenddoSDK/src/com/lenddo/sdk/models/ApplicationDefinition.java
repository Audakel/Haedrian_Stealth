package com.lenddo.sdk.models;

/**
 * Created by joseph on 8/14/14.
 */
public class ApplicationDefinition {
}
