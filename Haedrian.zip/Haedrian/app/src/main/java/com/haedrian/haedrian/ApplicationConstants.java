package com.haedrian.haedrian;

/**
 * Created by James on 3/21/2015.
 */
public class ApplicationConstants {
    public final static String base = "http://haedrian.io/";
    public final static String lenddo_social_service_secret = "";
    public final static String lenddo_social_service_userid = "";
    public final static String lenddo_product_service_secret = "";
    public final static String lenddo_product_service_userid = "";

    public final static String lenddo_member_service_userid = "55252b62aa96123cde054741";
    public final static String lenddo_member_service_secret = "gHZMXpsJV+OuHZzffC6xbOy3LZWOQToYi1SgOJGUeCrFukALvLkYrZoaBy/7LkQxuJq2N125jXorF6g+9xOVlQ==";
    public final static String lenddo_app_id = "55252b62aa96123cde05473f";
    public final static String lenddo_key_scriptId = "55252b62aa96123cde054740";



}
