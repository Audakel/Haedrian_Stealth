package com.haedrian.haedrian.DummyContent;

import com.haedrian.haedrian.R;

/**
 * Created by hbll-rm on 2/26/2015.
 */

// I used excel to format everything, so that's why all the long column format...
public class ProjectContent {
    public static String[] projectTitle = {
            "Cleaning",
            "Clothing",
            "Sewing",
            "Farm",
            "Education ",
            "Agriculture",
            "Health ",
            "Auto Repair",
            "Clothing",
            "Fuel/Firewood",
            "Livestock"
    };

    public static String[] personName = {
            "Fintan ",
            "Adel ",
            "Kenyatta",
            "Eolande",
            "Johari ",
            "Runako ",
            "Marjan ",
            "Shani ",
            "Naira ",
            "Einar ",
            "Tahir "
    };

    public static String[] projectLocation = {
            "Mali ",
            "Tanzania ",
            "Kenya ",
            "Peru ",
            "Senegal ",
            "Bolivia ",
            "Bolivia ",
            "Haiti ",
            "Philippines ",
            "Ghana ",
            "Uganda "

    };

    public static String[] projectDescription = {
            "helps to obtain more clients and contracts for her commercial cleaning and floor restoration company.",
            "buy clothes in bulk to resell.",
            "repair her tailoring machines.",
            "purchase materials for his tailor’s shop and farm (manure, weed killer, and seeds).",
            "train and get an education in graphic desing.",
            "buy beehives and apiary materials for honey production",
            "compra de productos de belleza por mayor.",
            "open an auto service shop and get a stable source of income.",
            "buy clothing and cosmetics in bulk to resell.",
            "buy more firewood to cover all of his customers' demands.",
            "renew her chicken pens."

    };

    public static int[] fundingGoal = {
            560,
            1000,
            2125,
            890,
            2500,
            775,
            3600,
            2000,
            1050,
            200,
            300
    };

    public static int[] currentAmountRaised = {
            400,
            50,
            1500,
            880,
            100,
            435,
            950,
            685,
            450,
            50,
            110

    };

    public static int[] projectImage = {
            R.drawable.invest1,
            R.drawable.invest2,
            R.drawable.invest3,
            R.drawable.invest4,
            R.drawable.invest5,
            R.drawable.invest6,
            R.drawable.invest7,
            R.drawable.invest8,
            R.drawable.invest9,
            R.drawable.invest10,
            R.drawable.invest11,
    };

    public static int[] daysLeft = {
            45, 23, 12, 10, 8, 19, 14, 22, 26, 11, 6
    };
}
